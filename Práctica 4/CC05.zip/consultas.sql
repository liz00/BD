GRANT CREATE VIEW TO DG05;

--1) Listado de los empleados con domicilio ordenados por C�digo postal y Nombre. vista1(Nombre, Calle, C�digo postal) 

CREATE VIEW vista1 AS
SELECT Empleados.Nombre, Domicilios.Calle, Domicilios."C�digo postal"
FROM Empleados, Domicilios
WHERE Empleados.dni = Domicilios.dni
ORDER BY Domicilios."C�digo postal", Empleados.Nombre;

Otra forma:
CREATE VIEW vista1(Nombre, Calle, "C�digo postal") AS 
SELECT Nombre, Calle, "C�digo postal" 
FROM Empleados NATURAL INNER JOIN Domicilios 
ORDER BY "C�digo postal", Nombre;

--2) Listado de los empleados que tengan tel�fono, ordenados por nombre. vista2(Nombre, DNI, Calle, C�digo postal, Tel�fono) 

CREATE VIEW vista2 AS
SELECT e.nombre, e.dni, d.Calle, d."C�digo postal", t.tel�fono
FROM empleados e LEFT JOIN domicilios d ON e.dni = d.dni 
INNER JOIN tel�fonos t ON t.dni=e.dni
ORDER BY e.nombre ASC;

--3) Listado de todos los empleados ordenados por nombre, tanto los empleados que tengan tel�fono como los que no. 
--vista3(Nombre, DNI, Calle, C�digo postal, Tel�fono) 
CREATE VIEW vista3 AS
SELECT e.nombre, e.dni, d.Calle, d."C�digo postal", t.tel�fono
FROM empleados e LEFT JOIN domicilios d ON e.dni = d.dni 
LEFT JOIN tel�fonos t ON t.dni=e.dni
ORDER BY e.nombre ASC;

--4) Listado de todos los empleados ordenados por nombre. vista4(Nombre, DNI, Calle, Poblaci�n, Provincia, C�digo postal) 
CREATE VIEW vista4 AS
SELECT e.Nombre, e.DNI, d.Calle, c.Poblaci�n, c.Provincia, d."C�digo postal"
FROM Empleados e LEFT JOIN Domicilios d ON e.DNI = d.DNI
LEFT JOIN "C�digos postales" c ON c."C�digo postal" = d."C�digo postal"
LEFT JOIN Tel�fonos t ON e.DNI = t.DNI
ORDER BY e.Nombre ASC;

--5) Listado de todos los empleados ordenados por nombre. vista5(Nombre, DNI, Calle, Poblaci�n, Provincia, C�digo postal, Tel�fono) 

CREATE VIEW vista5 AS
SELECT e.Nombre, e.DNI, d.Calle, c.Poblaci�n, c.Provincia, d."C�digo postal", t.tel�fono
FROM Empleados e LEFT JOIN Domicilios d ON e.DNI = d.DNI
LEFT JOIN "C�digos postales" c ON c."C�digo postal" = d."C�digo postal"
LEFT JOIN Tel�fonos t ON e.DNI = t.DNI
ORDER BY e.Nombre ASC;

--6) Mediante una instrucci�n UPDATE, incrementa en un 10% el sueldo de todos los empleados, de forma que el sueldo aumentado no supere en ning�n caso 1.900 �.

UPDATE Empleados SET Sueldo = Sueldo * 1.1 WHERE Sueldo * 1.1 <=1900;

--7) Deshaz la operaci�n anterior con otra instrucci�n UPDATE (comprobar que los datos coinciden con los de la tabla original).
UPDATE Empleados SET Sueldo = Sueldo / 1.1 WHERE Sueldo <=1900;

--8) Repite los dos pasos anteriores con el l�mite 1.600 �. �Qu� ocurre con los datos originales? 
UPDATE Empleados SET Sueldo = Sueldo * 1.1 WHERE Sueldo * 1.1 <=1600;
UPDATE Empleados SET Sueldo = Sueldo / 1.1 WHERE Sueldo <=1600; --Se actualizan dos filas y el de Laura no se hace correctamente, no vuelve a los datos orginales

--9) Listado que muestre n�mero total de empleados, el sueldo m�nimo, el m�ximo y el medio. vista9(Empleados, Sueldo m�nimo, Sueldo m�ximo, Sueldo medio) 

CREATE VIEW vista9 AS
SELECT COUNT(*) Empleados, MIN(e.Sueldo) "sueldo minimo" , MAX(e.Sueldo) "Sueldo maximo" , AVG(e.Sueldo) "Sueldo medio"
FROM Empleados e;

--10) Listado que muestre sueldo medio por poblaci�n y n�mero de empleados, ordenado por poblaci�n. vista10(Sueldo medio, N�mero empleados, Poblaci�n

CREATE VIEW vista10 AS
SELECT AVG(e.Sueldo) "Sueldo medio", COUNT(*) AS Empleados, c.Poblaci�n 
FROM Empleados e LEFT JOIN Domicilios d ON e.DNI = d.DNI
LEFT JOIN "C�digos postales" c ON c."C�digo postal" = d."C�digo postal"
GROUP BY c.Poblaci�n
ORDER BY c.Poblaci�n;

--11) Obtener los empleados que tengan m�s de un tel�fono, indicando Nombre, DNI y Tel�fono, ordenados por su nombre. vista10(Nombre, DNI, Tel�fono) 
--Vista 11 que la 10 ya existe :)

CREATE VIEW vista11 AS
SELECT e.Nombre, e.DNI, te.Tel�fono
FROM Empleados e, Tel�fonos t, Tel�fonos te
WHERE e.DNI = t.DNI AND
e.DNI = te.DNI AND
t.Tel�fono <> te.tel�fono
ORDER BY e.Nombre ASC;

--Otra forma: 
CREATE VIEW  vista11(Nombre, DNI, Tel�fono) AS
SELECT Nombre, DNI, Tel�fono
FROM Empleados NATURAL INNER JOIN Tel�fonos
WHERE COUNT(Tel�fono) > 1
ORDER BY Nombre

--12) Listado de provincias con c�digos postales ordenado por poblaci�n. En la cabecera de las columnas deben aparecer las provincias y 
--en cada columna los c�digos postales de las localidades de cada provincia como se indica en la tabla de abajo. vista11(Poblaci�n, Barcelona, C�rdoba, Madrid, Zaragoza): 
--Vista12 :)

CREATE VIEW vista12 AS
SELECT C.poblaci�n, C."C�digo postal" AS "Barcelona", NULL AS "C�rdoba", NULL AS "Madrid", NULL AS "Zaragoza"
FROM "C�digos postales" C
WHERE c.provincia = 'Barcelona'
UNION
SELECT C.poblaci�n, NULL AS "Barcelona", C."C�digo postal" AS "C�rdoba", NULL AS "Madrid", NULL AS "Zaragoza"
FROM "C�digos postales" C
WHERE c.provincia = 'C�rdoba'
UNION
SELECT C.poblaci�n,NULL AS "Barcelona", NULL AS "C�rdoba",C."C�digo postal" AS "Madrid", NULL AS "Zaragoza"
FROM  "C�digos postales" C
WHERE c.provincia = 'Madrid'
UNION
SELECT C.poblaci�n,NULL AS "Barcelona", NULL AS "C�rdoba", NULL AS "Madrid", C."C�digo postal" AS "Zaragoza"
FROM  "C�digos postales" C
WHERE c.provincia = 'Zaragoza'; 





