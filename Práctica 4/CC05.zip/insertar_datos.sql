DELETE FROM Tel�fonos;
DELETE FROM Tel;
DELETE FROM Tl;
DELETE FROM Empleados;
DROP TABLE Tel;
DROP TABLE Tl;

--1. Inserci�n de una fila con clave primaria duplicada
INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Ines', '33333333A', 2100.00);
  --1 fila insertadas.
INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Irene', '33333333A', 2000.00);
  /*INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Irene', '33333333A', 2000.00)
  Informe de error -
  ORA-00001: restricci�n �nica (CC05.SYS_C0012522) violada*/


--2. Inserci�n que no incluya todas las columnas que requieren un valor
INSERT INTO Empleados (Nombre, DNI) VALUES ('Irene', '33333332A');
  --1 fila insertadas.
INSERT INTO Empleados (DNI, sueldo) VALUES ('33333331A', 2000.00);
  /*INSERT INTO Empleados (DNI, sueldo) VALUES ('33333331A', 2000.00)
  Informe de error -
  ORA-01400: no se puede realizar una inserci�n NULL en ("CC05"."EMPLEADOS"."NOMBRE")*/
INSERT INTO Empleados VALUES ('123456785A', '5000');
  /*Error que empieza en la l�nea: 40 del comando -
  INSERT INTO Empleados VALUES ('123456785A', '5000')
  Error en la l�nea de comandos : 40 Columna : 13
  Informe de error -
  Error SQL: ORA-00947: not enough values
  00947. 00000 -  "not enough values"
  *Cause:    
  *Action:*/

  
--3. Inserci�n que no verifique las restricciones de dominio CHECK
INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Irene', '33333330A', 200.00);
  /*INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Irene', '33333330A', 200.00)
  Informe de error -
  ORA-02290: restricci�n de control (CC05.SYS_C0012521) violada*/
INSERT INTO Empleados VALUES ('Estibaliz Latorre', '15545678A', '5500');
  /*Error que empieza en la l�nea: 53 del comando :
  INSERT INTO Empleados VALUES ('Estibaliz Latorre', '15545678A', '5500')
  Informe de error -
  ORA-02290: check constraint (CC05.SYS_C007034) violated*/

  
--4. Inserci�n que no respete una regla de integridad referencial.
INSERT INTO Tel�fonos (DNI, Tel�fono) VALUES ('33333334A', '912675657');
  /*INSERT INTO Tel�fonos (DNI, Tel�fono) VALUES ('33333334A', '912675657')
  Informe de error -
  ORA-02291: restricci�n de integridad (CC05.SYS_C0012524) violada - clave principal no encontrada*/
  
  
--5. Borrado en una tabla padre con filas dependientes donde la FK tiene una regla de borrado ON DELETE NO ACTION (acci�n predeterminada; realmente esto no se puede escribir en Oracle)
CREATE TABLE Tel (
DNI CHAR(9) REFERENCES Empleados,
Tel�fono CHAR(9),
PRIMARY KEY (DNI, Tel�fono));
  --Table TEL creado.
INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Pablo', '33333339A', 2000.00);
  --1 fila insertadas.
INSERT INTO Tel (DNI, Tel�fono) VALUES ('33333339A', '912675657');
  --1 fila insertadas.
DELETE FROM Empleados WHERE DNI = '33333339A';
  /*DELETE FROM Empleados WHERE DNI = '33333339A'
  Informe de error -
  ORA-02292: restricci�n de integridad (CC05.SYS_C0014256) violada - registro secundario encontrado*/


--6. Borrado en una tabla padre con filas dependientes donde la FK tiene una regla de borrado ON DELETE CASCADE. Por ejemplo, borra un empleado y documenta lo que sucede con sus tel�fonos y direcciones
INSERT INTO Tel�fonos (DNI, Tel�fono) VALUES ('33333333A', '912675658');
  --1 fila insertadas.
DELETE FROM Empleados WHERE DNI = '33333333A';
  --1 fila eliminado
SELECT * FROM Tel�fonos WHERE DNI = '33333333A';
  --no se ha seleccionado ninguna fila
  /*Al crear la tabla T�lefonos como el DNI referencia al DNI de la tabla Empleados
  ON DELETE CASCADE, al borrar la tupla del empleado con DNI 33333333A, se borra
  no solo en la tabla empleados sino tambi�n en la tabla tel�fonos. Al buscar en 
  la tabla Tel�fonos la tupla con DNI 33333333A, sale que no existe porque se ha 
  borrado junto con la tupla de este mismo DNI pero en la tabla Empleados.*/
  
 
--7.Borrado en Empleados cuando Tel�fonos tiene una regla de borrado ON DELETE SET NULL sobre el campo DNI
CREATE TABLE Tl (
DNI CHAR(9) REFERENCES Empleados ON DELETE SET NULL,
Tel�fono CHAR(9),
PRIMARY KEY (DNI, Tel�fono));
  --Table TL creado.
INSERT INTO Empleados (Nombre, DNI, Sueldo) VALUES ('Andres', '33333338A', 2000.00);
  --1 fila insertadas.
INSERT INTO Tl (DNI, Tel�fono) VALUES ('33333338A', '912675627');
  --1 fila insertadas.
DELETE FROM Empleados WHERE DNI = '33333338A';
  /*DELETE FROM Empleados WHERE DNI = '33333338A'
  Informe de error -
  ORA-01407: no se puede actualizar ("CC05"."TL"."DNI") a un valor NULL*/


