SELECT TABLE_NAME FROM USER_TABLES; 
-- Permite ver las tablas creadas por el usuario conectado 
-- O mejor, verlas en SQL Developer (la vista se actualiza con Ctrl+R) 

/*Borrar tablas*/

DROP TABLE Tel�fonos CASCADE CONSTRAINTS;
DROP TABLE Domicilios CASCADE CONSTRAINTS;
DROP TABLE "C�digos postales" CASCADE CONSTRAINTS;
DROP TABLE Empleados CASCADE CONSTRAINTS;

/*Crear tablas*/

CREATE TABLE Empleados (
 Nombre CHAR(50) NOT NULL,
 DNI CHAR(9),
 Sueldo NUMBER(6,2),
 CHECK (Sueldo BETWEEN 735.90 AND 5000.00),
 PRIMARY KEY (DNI));
 
 --Table EMPLEADOS creado.
 
CREATE TABLE Tel�fonos (
 DNI CHAR(9) REFERENCES Empleados ON DELETE CASCADE,
 Tel�fono CHAR(9),
 PRIMARY KEY (DNI, Tel�fono));
 
 --Table TEL�FONOS creado.
 
CREATE TABLE "C�digos postales"(
 "C�digo postal" CHAR(5) PRIMARY KEY,
 Poblaci�n CHAR(50),
 Provincia CHAR(50));
 
 --Table "C�digos postales" creado.
 
CREATE TABLE Domicilios (
 DNI CHAR(9) REFERENCES Empleados ON DELETE CASCADE,
 Calle CHAR(50),
 "C�digo postal" CHAR(5) REFERENCES "C�digos postales" ON DELETE CASCADE,
 PRIMARY KEY (DNI, Calle, "C�digo postal"));
 
 --Table DOMICILIOS creado.

SELECT * FROM USER_TABLES;
--